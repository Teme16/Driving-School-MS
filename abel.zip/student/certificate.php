<?php
session_start();
require_once '../config/db.php';

if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student'){
    header('Location: ../login.php');
    exit();
}

$student_id = intval($_SESSION['user_id']);
$page_title = 'My Certificates';
try {
    $stmt = $pdo->prepare("SELECT c.*, e.program_id FROM certificates c LEFT JOIN enrollments e ON c.enrollment_id = e.enrollment_id WHERE c.student_user_id = ? ORDER BY c.issue_date DESC");
    $stmt->execute([$student_id]);
    $certs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $certs = [];
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Certificates</title>
    <link rel="stylesheet" href="../assets/css/style.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <div class="app-wrapper">
      <?php include __DIR__ . '/includes/sidebar.php'; ?>
      <div class="main-content">
        <?php include __DIR__ . '/includes/topbar.php'; ?>
      <main class="page-content">
        <div class="card">
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>#</th><th>Certificate No</th><th>Issued</th><th>Action</th></tr></thead>
              <tbody>
                <?php foreach($certs as $c): ?>
                <tr>
                  <td><?php echo intval($c['certificate_id']); ?></td>
                  <td><?php echo htmlspecialchars($c['certificate_number']); ?></td>
                  <td><?php echo date('Y-m-d', strtotime($c['issue_date'])); ?></td>
                  <td class="d-flex gap-sm flex-wrap">
                    <a class="btn btn-outline btn-sm" href="certificate_download.php?cert_id=<?php echo intval($c['certificate_id']); ?>" target="_blank">View</a>
                    <a class="btn btn-outline btn-sm" href="certificate_download.php?cert_id=<?php echo intval($c['certificate_id']); ?>&print=1" target="_blank">Print</a>
                    <a class="btn btn-primary btn-sm" href="certificate_download.php?cert_id=<?php echo intval($c['certificate_id']); ?>&download=1">Download</a>
                  </td>
                </tr>
                <?php endforeach; ?>
                <?php if(count($certs)===0): ?><tr><td colspan="4" class="text-center text-muted">No certificates issued yet.</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </main>
      </div>
    </div>
  </body>
</html>
